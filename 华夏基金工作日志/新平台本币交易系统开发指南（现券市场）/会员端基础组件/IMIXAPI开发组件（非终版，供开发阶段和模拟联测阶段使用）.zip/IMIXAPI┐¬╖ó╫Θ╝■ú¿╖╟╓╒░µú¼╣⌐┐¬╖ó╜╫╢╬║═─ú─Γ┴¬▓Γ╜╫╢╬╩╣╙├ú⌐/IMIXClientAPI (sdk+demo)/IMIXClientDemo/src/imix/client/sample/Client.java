/**
 * Client.java
 * 
 * Copyright (c) 2007 China Foreign Exchange Trade System and National Interbank Funding Center.
 * Building 30,1387 zhangdong Road, Shanghai, China.
 * All rights reserved.
 *
 * "[Description of code or deliverable as appropriate] is the copyrighted,
 * proprietary property of China Foreign Exchange Trade System and National
 * Interbank Funding Center which retain all right, title and interest therein."
 * 
 * Copyright (c) 2006 State Street Bank and Trust Corp.
 * 225 Franklin Street, Boston, MA 02110, U.S.A.
 * All rights reserved.
 *
 * "[Description of code or deliverable as appropriate] is the copyrighted,
 * proprietary property of State Street Bank and Trust Company and its
 * subsidiaries and affiliates which retain all right, title and interest
 * therein."
 * 
 * Revision History
 *
 * Date            Programmer              Notes
 * ---------    ---------------------  --------------------------------------------
 * 2007-8-24      Mike Gu, Bill Zhou       initial
 */

package imix.client.sample;

import imix.ConfigError;
import imix.client.core.ImixApplication;
import imix.client.core.ImixSession;

public class Client {

	/**
	 * This is a simply examples using client API, and it is used only for demo.
	 * Please don't use it in product environment.
	 * 
	 * @author Mike Gu
	 */

	public static void main(String[] args) throws ConfigError {

		/**
		 * initializate the application
		 */
		try {
			ClientListener listener = new ClientListener();
					
			String configfile = "cfg/client.cfg";
			ImixApplication.initialize(listener, configfile);
			/**
			 * start the ImixSession 
			 */
			String userName = "shouxin01";
			String password = "bia5kf47r6";

			ImixSession imixSession = null;
			try {
				imixSession = new ImixSession(userName, password);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
			boolean isLogon = imixSession.start();
			if(isLogon == false){
			//	System.out.println(imixSession.getLogonError());
				imixSession.stop();
				ImixApplication.stop();
			}else{
			}

			try {
				Thread.sleep(10000L);
			} catch (Exception e) {
				e.printStackTrace();
			}
//			ImixApplication.stop();
//			PartyRiskLimitsRequest party = GenericMessage
//					.getRiskLimits15();
//			imixSession.send(party);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}