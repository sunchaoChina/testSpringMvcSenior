/**
 * Demo.java
 * 
 * Copyright (c) 2007 China Foreign Exchange Trade System and National Interbank Funding Center.
 * Building 30,1387 zhangdong Road, Shanghai, China.
 * All rights reserved.
 *
 * "[Description of code or deliverable as appropriate] is the copyrighted,
 * proprietary property of China Foreign Exchange Trade System and National
 * Interbank Funding Center which retain all right, title and interest therein."
 * 
 * Copyright (c) 2006 State Street Bank and Trust Corp.
 * 225 Franklin Street, Boston, MA 02110, U.S.A.
 * All rights reserved.
 *
 * "[Description of code or deliverable as appropriate] is the copyrighted,
 * proprietary property of State Street Bank and Trust Company and its
 * subsidiaries and affiliates which retain all right, title and interest
 * therein."
 * 
 * Revision History
 *
 * Date            Programmer              Notes
 * ---------    ---------------------  --------------------------------------------
 * 2007-8-24      Mike Gu     initial
 */

package imix.client.sample;

import imix.DataDictionary;
import imix.Field;
import imix.FieldMap;
import imix.FieldNotFound;
import imix.FieldType;
import imix.Group;
import imix.IncorrectTagValue;
import imix.Message;
import imix.StringField;
import imix.UnsupportedMessageType;
import imix.client.core.ImixSession;
import imix.client.core.Listener;
import imix.client.core.MessageCracker;
import imix.field.DBSQLStatement;
import imix.field.DataBaseName;
import imix.field.DeliverToCompID;
import imix.field.MsgType;
import imix.field.QueryDBSchemaName;
import imix.field.QueryDBTableName;
import imix.field.QueryDataBaseName;
import imix.field.QueryPageSize;
import imix.field.QueryRequestID;
import imix.field.QueryStartNumber;
import imix.field.QueryType;
import imix.imix10.ExecutionReport;
import imix.imix10.QueryReject;
import imix.imix10.QueryRequest;
import imix.imix10.QueryResult;
import imix.imix10.QueryResult.NoDBNames;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientListener extends MessageCracker implements Listener {
	
	private static Logger log = LoggerFactory.getLogger("SampleIMIXClient");
	private HashMap<String, PrintWriter> inLogger = new HashMap<String, PrintWriter>();
    private HashMap<String, PrintWriter> outLogger = new HashMap<String, PrintWriter>();
    private String m_outputDir = null;

    public void fromApp(Message message, ImixSession imixSession) throws UnsupportedMessageType, FieldNotFound,
            IncorrectTagValue {
//        System.out.println("==============fromApp()=================");
//        System.out.println("imixSession:" + imixSession);
//        messageCrack(message);
//        System.out.println("========================================");
    	printMsg(message, imixSession, true);
    }

    public void onLogon(ImixSession imixSession) {
        /*System.out.println("==============onLogon()=================");
        System.out.println("imixSession:" + imixSession);
        System.out.println("========================================");*/
    	log.info("Receive logon Ack from user session: (sessionID)" + imixSession.getSessionID());
    }

    public void onLogout(ImixSession imixSession) {
        /*System.out.println("==============onLogout()================");
        System.out.println("imixSession:" + imixSession);
        System.out.println("========================================");*/
    	log.info("Receive logout from user session(sessionID): " + imixSession.getSessionID());
    }

    public void toApp(Message message, ImixSession imixSession) {
//        System.out.println("==============toApp()===================");
//        System.out.println("imixSession:" + imixSession);
//        System.out.println("========================================");
    	printMsg(message, imixSession, false);
    	
    }

    public void fromAdmin(Message message, ImixSession imixSession) {
//        System.out.println("==============fromAdmin()===============");
//        System.out.println("imixSession:" + imixSession);
//        System.out.println("========================================");
    	printMsg(message, imixSession, true);
    }

    public void onError(ImixSession imixSession, int type) {
        /*System.out.println("==============onError()=================");
        if (Listener.CONNECTION_FAILURE == type){
            System.out.println("connection failure");
            System.out.println("========================================");
        }*/
    	log.error("Receive connection error from user session: " + imixSession.getSessionID());
    }
    
    public void onMessage(QueryReject queryReject) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue
    {  
        //print message received
        DataDictionary dd = ImixSession.lookupIMIXSession(queryReject).getDataDictionary();        
        String msgType = queryReject.getHeader().getString(MsgType.FIELD);
        System.out.println("\r\n\r\n");//
        printFieldMap("", dd, msgType, queryReject);
        System.out.println("\r\n\r\n");//
        
        //get message received
        QueryRequestID queryRequestID = new QueryRequestID();
        QueryType queryType = new QueryType();
        queryReject.get(queryRequestID);
        queryReject.get(queryType);

        QueryRequest queryRequest = new QueryRequest();
        queryRequest.setString(queryRequestID.getField(), idPlusOne(queryRequestID));
        queryRequest.set(queryType);
        queryRequest.set(new QueryDataBaseName("D*"));       

        /**
         *  set the DeliverToCompID
         */       
        queryRequest.getHeader().setString(DeliverToCompID.FIELD, "CFETS");        
        ImixSession.lookupIMIXSession(queryReject).send(queryRequest);
    }
    
    public void onMessage(QueryResult queryResult) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue
    {  
        //print message received
        DataDictionary dd = ImixSession.lookupIMIXSession(queryResult).getDataDictionary();        
        String msgType = queryResult.getHeader().getString(MsgType.FIELD);
        System.out.println("\r\n\r\n");//
        printFieldMap("", dd, msgType, queryResult);
        System.out.println("\r\n\r\n");//
        
        //get message received
        Message msg = new Message();
        QueryType queryType = new QueryType();  
        queryResult.get(queryType);
        
//        if(queryType.getValue() == 21)
//        {
//            msg = queryRequest_QueryType_22(queryResult);
//        }
//        else if(queryType.getValue() == 22)
//        {
//            msg = queryRequest_QueryType_23(queryResult);
//        }
//        else if(queryType.getValue() == 23)
//        {
//            msg = queryRequest_QueryType_25(queryResult);
//        }
//        else if(queryType.getValue() == 25)
//        {
//            msg = queryRequest_QueryType_30(queryResult);
//        }
//        else
//        {
//            msg = null;
//        }
        
        if( msg != null )
        {
            msg.getHeader().setString(DeliverToCompID.FIELD, "CFETS");        
            ImixSession.lookupIMIXSession(queryResult).send(msg);
        } 
        
    }
    
    public static QueryRequest queryRequest_QueryType_22(QueryResult queryResult) throws FieldNotFound 
    {
        //get message received        
        QueryRequestID queryRequestID = new QueryRequestID();
        NoDBNames noDBNames = new NoDBNames();
        DataBaseName dataBaseName = new DataBaseName();        
        queryResult.get(queryRequestID);
        queryResult.getGroup(1, noDBNames);
        noDBNames.get(dataBaseName);
        
        QueryRequest queryRequest = new QueryRequest();
        queryRequest.setString(queryRequestID.getField(), idPlusOne(queryRequestID));
        queryRequest.set(new QueryType(22));
        queryRequest.set(new QueryDataBaseName(dataBaseName.getValue()));
        queryRequest.set(new QueryDBSchemaName("D*"));
       
        return queryRequest;
    }
    
    public static QueryRequest queryRequest_QueryType_23(QueryResult queryResult) throws FieldNotFound 
    {
        //get message received
        QueryRequestID queryRequestID = new QueryRequestID();
        QueryDataBaseName queryDataBaseName = new QueryDataBaseName();        
        queryResult.get(queryRequestID);
        queryResult.get(queryDataBaseName);         
        
        QueryRequest queryRequest = new QueryRequest();
        queryRequest.setString(queryRequestID.getField(), idPlusOne(queryRequestID));
        queryRequest.set(new QueryType(23));
        queryRequest.set(queryDataBaseName);
       
        return queryRequest;
    } 
    
    public static QueryRequest queryRequest_QueryType_25(QueryResult queryResult) throws FieldNotFound 
    {
        //get message received        
        QueryRequestID queryRequestID = new QueryRequestID();
        QueryDataBaseName queryDataBaseName = new QueryDataBaseName();        
        queryResult.get(queryRequestID);
        queryResult.get(queryDataBaseName); 
        
        QueryRequest queryRequest = new QueryRequest();
        queryRequest.setString(queryRequestID.getField(), idPlusOne(queryRequestID));
        queryRequest.set(new QueryType(25));
        queryRequest.set(queryDataBaseName);
        queryRequest.set(new QueryDBSchemaName("FC"));
        queryRequest.set(new QueryDBTableName("u*"));
       
        return queryRequest;
    } 
    
    public static QueryRequest queryRequest_QueryType_30(QueryResult queryResult) throws FieldNotFound 
    {
        //get message received        
        QueryRequestID queryRequestID = new QueryRequestID();
        QueryDataBaseName queryDataBaseName = new QueryDataBaseName();        
        queryResult.get(queryRequestID);
        queryResult.get(queryDataBaseName);         
        
        QueryRequest queryRequest = new QueryRequest();
        queryRequest.setString(queryRequestID.getField(), idPlusOne(queryRequestID));
        queryRequest.set(new QueryType(30));
        queryRequest.set(queryDataBaseName);
        queryRequest.set(new DBSQLStatement("select * from user"));
        queryRequest.set(new QueryPageSize(5));
        queryRequest.set(new QueryStartNumber(10));
       
        return queryRequest;
    } 

    public void onMessage(ExecutionReport executionReport) throws FieldNotFound, UnsupportedMessageType, IncorrectTagValue
    {      
        //get message received        
//        ExecID execID = new ExecID();
//        TradeDate tradeDate = new TradeDate(); 
//        TotNumReports totNumReports = new TotNumReports(); 
//        LastRptRequested lastRptRequested = new LastRptRequested(); 
//        QueryRequestID queryRequestID = new QueryRequestID(); 
//        QueryPageNumber queryPageNumber = new QueryPageNumber();       
//        NoPartyIDs noPartyIDs = new NoPartyIDs();
//        PartyID partyID = new PartyID();
//        PartyRole partyRole = new PartyRole();        
//        NoPartySubIDs noPartySubIDs = new NoPartySubIDs();        
//        PartySubID partySubID = new PartySubID();
//        PartySubIDType partySubIDType = new PartySubIDType(); 
//       
//        SimpleDateFormat datafmt = new SimpleDateFormat("yyyyMMdd");
//        try{
//            executionReport.set(new TradeDate(datafmt.parse("20071123")));
//        }catch(ParseException e){
//            
//        }         
//       
//        executionReport.get(execID);
//        executionReport.get(tradeDate);
//        executionReport.get(totNumReports);
//        executionReport.get(lastRptRequested);
//        executionReport.get(queryRequestID);
//        executionReport.get(queryPageNumber);
//        System.out.println(execID.getValue());
//        System.out.println(tradeDate.getValue());
//        System.out.println(totNumReports.getValue());
//        System.out.println(lastRptRequested.getValue());
//        System.out.println(queryRequestID.getValue());
//        System.out.println(queryPageNumber.getValue());
//        
//        System.out.println("------");
//        System.out.println(executionReport.get(new imix.field.NoPartyIDs()).getValue());
//        System.out.println(" ------");
//        
//        for(int i = 1; i <= executionReport.get(new imix.field.NoPartyIDs()).getValue(); i++)
//        {
//            executionReport.getGroup(i, noPartyIDs);
//            noPartyIDs.get(partyID);            
//            noPartyIDs.get(partyRole);
//            System.out.println(" -> " + partyID.getValue());
//            System.out.println(" -> " + partyRole.getValue()); 
//            
//            System.out.println("    ------");
//            System.out.println(" -> " + noPartyIDs.get(new imix.field.NoPartySubIDs()).getValue());
//            System.out.println("    ------");
//            
//            for(int j = 1; j <= noPartyIDs.get(new imix.field.NoPartySubIDs()).getValue(); j++)
//            {
//                noPartyIDs.getGroup(j, noPartySubIDs);
//                noPartySubIDs.get(partySubID);                
//                noPartySubIDs.get(partySubIDType);
//                System.out.println(" -> -> " + partySubID.getValue());
//                System.out.println(" -> -> " + partySubIDType.getValue());
//                System.out.println("    ------");
//            } 
//            
//            System.out.println(" ------");
//        }
//        
//        System.out.println("------");
        
        
        //print message received
        DataDictionary dd = ImixSession.lookupIMIXSession(executionReport).getDataDictionary();
        
        String msgType = executionReport.getHeader().getString(MsgType.FIELD);
        printFieldMap("", dd, msgType, executionReport.getHeader());
        printFieldMap("", dd, msgType, executionReport);
        printFieldMap("", dd, msgType, executionReport.getTrailer()); 
    }
    
    
    private static void printFieldMap(String prefix, DataDictionary dd, String msgType, FieldMap fieldMap) throws FieldNotFound
    {
        Iterator fieldIterator = fieldMap.iterator();
        while (fieldIterator.hasNext()) {
            Field field = (Field) fieldIterator.next();
            if (!isGroupCountField(dd, field)) {
                String value = fieldMap.getString(field.getTag());
                if (dd.hasFieldValue(field.getTag())) {
                    value = dd.getValueName(field.getTag(), fieldMap.getString(field.getTag())) + " (" + value + ")";
                }
                System.out.println(prefix + dd.getFieldName(field.getTag()) + ": " + value);
            }
        }

        Iterator groupsKeys = fieldMap.groupKeyIterator();
        while (groupsKeys.hasNext()) {
            int groupCountTag = ((Integer) groupsKeys.next()).intValue();
            System.out.println(prefix + dd.getFieldName(groupCountTag) + ": count = "
                    + fieldMap.getInt(groupCountTag));
            Group g = new Group(groupCountTag, 0);
            int i = 1;
            while (fieldMap.hasGroup(i, groupCountTag)) {
                if (i > 1) {
                    System.out.println(prefix + "  ----");
                }
                fieldMap.getGroup(i, g);
                printFieldMap(prefix + "  ", dd, msgType, g);
                i++;
            }
        }
    }

    private static boolean isGroupCountField(DataDictionary dd, Field field)
    {
        return dd.getFieldTypeEnum(field.getTag()) == FieldType.NumInGroup;
    }
    
    private static String idPlusOne(StringField field)
    {
        String str = field.getValue();
        char[] id = new char[str.length()];
        str.getChars(0, str.length(), id, 0);
        
        str = new String(plusOne(id, str.length()-1));
        return str;
    }
    
    private static char[] plusOne(char[] id, int address)
    {
        char a = id[address];
        if(a < '9' && a >= '0')
        {
            id[address] = (char)(a+1);
        }
        else if(a == '9')
        {
            id[address] = '0';
            if(address > 0)
            {
                plusOne(id, address-1);
            }            
        }        
        return id;
    }    

    private void printMsg(Message message, ImixSession imixSession, boolean isInbound) {
        PrintWriter writter = null;
        if (isInbound) {
            writter = inLogger.get(imixSession.getSessionID());
            if (writter == null) {
                try {
                    writter = new PrintWriter(m_outputDir  + File.separator + imixSession.getSessionID() + "-rx.log");
                } catch (final FileNotFoundException e) {
                    e.printStackTrace();
                }
                // modify by xuanjun
                inLogger.put(imixSession.getSessionID().toString(), writter);
            }
        } else {
            writter = outLogger.get(imixSession.getSessionID());
            if (writter == null) {
                try {
                    writter = new PrintWriter(m_outputDir + File.separator + imixSession.getSessionID() + "-tx.log");
                } catch (final FileNotFoundException e) {
                    e.printStackTrace();
                }
                // modify by xuanjun
                outLogger.put(imixSession.getSessionID().toString(), writter);
            }
        }
        writter.println(message.toString());
        writter.flush();
    }
    
   public void setOutDir(String path){
	   this.m_outputDir = path;
   }
    
}
