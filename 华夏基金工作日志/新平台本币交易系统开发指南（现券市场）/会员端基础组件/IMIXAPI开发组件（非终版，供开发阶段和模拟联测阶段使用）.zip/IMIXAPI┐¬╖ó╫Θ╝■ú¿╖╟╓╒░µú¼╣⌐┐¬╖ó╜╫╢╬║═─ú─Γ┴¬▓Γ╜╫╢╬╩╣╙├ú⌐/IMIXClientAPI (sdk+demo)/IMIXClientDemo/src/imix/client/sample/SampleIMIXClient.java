////////////////////////////////////////////////////////////////////////////////
//
// SampleIMIXClient.java
//
// Copyright (c) 2016 China Foreign Exchange Trade System and National Interbank Funding Center.
// Building 30, 1387 ZhangDong Road, Shanghai, China.
// All rights reserved.
//
// Data Exchange Platform (DEP) is the copyrighted,
// proprietary property of China Foreign Exchange Trade System and National
// Interbank Funding Center which retain all right, title and interest therein.
//
// Description: SampleIMIXClient class
//
////////////////////////////////////////////////////////////////////////////////

package imix.client.sample;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.PropertyConfigurator;
import org.apache.mina.filter.SSLFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import imix.ConfigError;
import imix.DataDictionary;
import imix.InvalidMessage;
import imix.Message;
import imix.client.core.ImixApplication;
import imix.client.core.ImixSession;
import imix.client.core.ImixSessionExistingException;

public class SampleIMIXClient {
    private static Logger Log = null;
    private String m_outputDir = null;
    
    private static final class ClientNode {
        ImixSession imixClient = null;
        BufferedReader msgFile = null;

        public ClientNode(final String username, final String password)
                throws ConfigError, ImixSessionExistingException, IOException {
            imixClient = new ImixSession(username, password);
        }
        
        
        public ClientNode(final String username, final String password, final String market)
                throws ConfigError, ImixSessionExistingException, IOException {
            imixClient = new ImixSession(username, password, market);
        }
        
        public ClientNode(final String username, final String password, final String senderCompId, final String targetCompId)
                throws ConfigError, ImixSessionExistingException, IOException {
            imixClient = new ImixSession(username, password, senderCompId, targetCompId);
        }
        
        public ClientNode(final String username, final String password, final String senderCompId, final String targetCompId, final String targetSubId)
                throws ConfigError, ImixSessionExistingException, IOException {
            imixClient = new ImixSession(username, password, senderCompId, targetCompId, targetSubId);
        }
        
        //cfg/benjunyun/client.cfg 30 data/store/ Y iclient1,123456,cfg/benjunyun/iclient1.txt iclient1,123456,cfg/benjunyun/iclient1.txt 
        public final boolean runNextCommand() throws NumberFormatException, IOException, InterruptedException {
            if (msgFile == null)
                return true;
            String line;
            String[] arg;
            while ((line = msgFile.readLine()) != null) {
                if (line.startsWith("#"))
                    continue;
                arg = line.split(",");

                if (arg.length < 2)
                    continue;

                if (arg[0].equals("S")) {
                    Thread.sleep(Long.parseLong(arg[1]));
                    return true;
                } else if (arg[0].equals("D")) {
                    Message msg;
                    try {
                        msg = new Message(arg[2],new DataDictionary("IMIX20.xml"), false);
                    } catch (final InvalidMessage e) {
                        e.printStackTrace();
                        continue; // Skip this message and process next
                    } catch (ConfigError e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						continue;
					}
                   /* boolean rtc = imixClient.send(msg);
                    if (!rtc)
                        Log.error("Fail to send msg:" + msg.toString());*/
                    //long starttime = System.nanoTime();
                    int num = Integer.parseInt(arg[1]);
                    for(int i = 0; i < num; i++){
                    	boolean rtc = imixClient.send(msg);
                        if (!rtc)
                            Log.error("Fail to send msg:" + msg.toString());
                    }
                    //Log.error("num 10000:  time:  " + (System.nanoTime()-starttime));

                    return true;
                }
            }
            return false;
        }
        
        public void stop() {
            imixClient.stop();
        }
    }

    //cfg/benjunyun/client.cfg 30 data/store/ Y iclient1,123456,cfg/benjunyun/iclient1.txt
    private void start(String[] args) {
        try {
            Log = LoggerFactory.getLogger("SampleIMIXClient");
            int overtime = Integer.parseInt(args[1]);
            if (overtime <= 0)
                throw new Exception("Overtime value should greater than 0");
            
            m_outputDir = args[2];
            File f = new File(m_outputDir);
            if (!f.exists() || !f.isDirectory())
                throw new ConfigError("Log directory not exist");
            // add by xuanjun
            ClientListener listener = new ClientListener();
            listener.setOutDir(m_outputDir);
            ImixApplication.initialize(listener, args[0]);
            Vector<ClientNode> clientVector = new Vector<ClientNode>();
            final boolean bExitIfStartupFailed = args[3].equals("Y");
            final int sessionStartIndex = 4;

            String msgFilePath = "";
            for (int i = sessionStartIndex; i < args.length; ++i) {
                List<String> list = new ArrayList<String>(Arrays.asList(args[i].split(",")));
                if (list.size() < 2)
                    throw new Exception("Invalid session setting");
                final String username = list.get(0);
                ClientNode client = null;
                try {
                	if (3 == list.size()) {
                		client = new ClientNode(username, list.get(1));
                		msgFilePath = list.get(2);
					} else if (4 == list.size()) {
						client = new ClientNode(username, list.get(1), list.get(2));
						msgFilePath = list.get(3);
					} else if (5 == list.size()) {
						client = new ClientNode(username, list.get(1), list.get(2), list.get(3));
						msgFilePath = list.get(4);
					} else if (6 == list.size()) {
						client = new ClientNode(username, list.get(1), list.get(2), list.get(3), list.get(4));
						msgFilePath = list.get(5);
					}
                    
                } catch (final ConfigError t) {
                    t.printStackTrace();
                    Log.info(t.getMessage());
                    continue;
                }
                boolean rtc = false;
                while (!(rtc = client.imixClient.start(overtime)) && !bExitIfStartupFailed)
                    Thread.sleep(1000);
                if (!rtc) {
                    Log.error("Session:" + username + " failed to startup");
                } else {
                    if (list.size() > 2) {
                        client.msgFile = new BufferedReader(new FileReader(msgFilePath));
                    }
                    clientVector.add(client);
                }
            }

            boolean doSth = false;
            do {
                doSth = false;
                for (int i = 0; i < clientVector.size(); ++i) {
                    doSth = clientVector.get(i).runNextCommand() || doSth;
                }

            } while (doSth);
            
            Thread.sleep(100000000);
//            for (int i = 0; i < clientVector.size(); ++i) {
//                clientVector.get(i).stop();
//            }
//
//            ImixApplication.stop();

        } catch (final Exception t) {
            t.printStackTrace();
            Log.info(t.getMessage());
            System.exit(1);
        }
    }

    public static void main(String[] args) {
    	/*try {
			initializeLog(args[0]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
        SampleIMIXClient imixClient = new SampleIMIXClient();
        imixClient.start(args);
    }

    
    public static final boolean initializeLog(final String configFile) throws IOException {
        String propertiesFilePath = "";
        final BufferedReader fr = new BufferedReader(new FileReader(new File(configFile)));
        String input = "";
        int index = 0;
        try {
            while ((input = fr.readLine()) != null) {
                index = input.indexOf("SLF4JLogPropertiesFilePath=");
                if (index == 0) {
                    propertiesFilePath = input.substring(index + "SLF4JLogPropertiesFilePath=".length(), input.length());
                    if (false == new File(propertiesFilePath).exists()) {
                    	Log.error("can not find " + propertiesFilePath);
                        System.exit(0);
                    }
                    break;
                }
            }
        } catch(final Exception e) {
            e.printStackTrace();
        } finally {
            fr.close();
        }
        if (propertiesFilePath.equals("")) {
            if (new File("log4j.properties").exists())
                propertiesFilePath = "log4j.properties";
            else
                return false;
        }
        PropertyConfigurator.configure(propertiesFilePath);
        return true;
    }
    
}
